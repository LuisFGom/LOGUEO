﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using UniversidadAPI.Data;
using UniversidadAPI.Models;
using UniversidadAPI.Recursos;

namespace UniversidadAPI.Controllers
{
    public class EstudiantesController : Controller
    {
        private readonly AppDbContext _context;

        public EstudiantesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Estudiantes
        public async Task<IActionResult> Index(string cedula, string nombre, string apellido, int page = 1)
        {
            int pageSize = 10; // Número de registros por página
            var estudiantesQuery = _context.Estudiantes.Include(e => e.oCarrera).AsQueryable();

            // Filtrado de estudiantes basado en la búsqueda individual
            if (!string.IsNullOrEmpty(cedula))
            {
                estudiantesQuery = estudiantesQuery.Where(e => e.Cedula.Contains(cedula));
            }

            if (!string.IsNullOrEmpty(nombre))
            {
                estudiantesQuery = estudiantesQuery.Where(e => e.Nombre.Contains(nombre));
            }

            if (!string.IsNullOrEmpty(apellido))
            {
                estudiantesQuery = estudiantesQuery.Where(e => e.Apellido.Contains(apellido));
            }

            var totalEstudiantes = await estudiantesQuery.CountAsync();

            var estudiantes = await estudiantesQuery
                                    .Skip((page - 1) * pageSize)
                                    .Take(pageSize)
                                    .ToListAsync();

            ViewBag.TotalPages = Math.Ceiling((double)totalEstudiantes / pageSize);
            ViewBag.CurrentPage = page;
            ViewBag.Cedula = cedula;
            ViewBag.Nombre = nombre;
            ViewBag.Apellido = apellido;

            return View(estudiantes);
        }

        // GET: Estudiantes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudiante = await _context.Estudiantes
                .Include(e => e.oCarrera)
                .FirstOrDefaultAsync(m => m.IdEstudiante == id);
            if (estudiante == null)
            {
                return NotFound();
            }

            return View(estudiante);
        }

        // GET: Estudiantes/Create
        public IActionResult Create()
        {
            ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre");
            return View();
        }

        // POST: Estudiantes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Cedula,Nombre,Apellido,IdCarrera")] Estudiante estudiante)
        {
            ModelState.Remove("Correo");
            if (ModelState.IsValid)
            {
                if (Utilidades.YaExisteCedula(estudiante.Cedula, _context))
                {
                    ModelState.AddModelError("", "La cédula ya está registrada.");
                    ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
                    return View(estudiante);
                }

                if (Utilidades.VerificarCampos(estudiante))
                {
                    estudiante.Nombre = Utilidades.NormalizarTexto(estudiante.Nombre);
                    estudiante.Apellido = Utilidades.NormalizarTexto(estudiante.Apellido);
                    estudiante.Correo = Utilidades.GenerarCorreo(estudiante);
                    _context.Add(estudiante);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    ModelState.AddModelError("", "Verifica los campos Nombre, Apellido y Cédula.");
                    ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
                    return View(estudiante);
                }
            }

            ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante?.IdCarrera);
            return View(estudiante);
        }

        // GET: Estudiantes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudiante = await _context.Estudiantes.FindAsync(id);
            if (estudiante == null)
            {
                return NotFound();
            }
            ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
            return View(estudiante);
        }

        // POST: Estudiantes/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEstudiante,Cedula,Nombre,Apellido,Correo,IdCarrera")] Estudiante estudiante)
        {
            if (id != estudiante.IdEstudiante)
            {
                return NotFound();
            }

            ModelState.Remove("Correo");
            if (ModelState.IsValid)
            {
                if (Utilidades.YaExisteCedula(estudiante.Cedula, _context, id))
                {
                    ModelState.AddModelError("", "La cédula ya está registrada.");
                    ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
                    return View(estudiante);
                }
                try
                {
                    if (Utilidades.VerificarCampos(estudiante))
                    {
                        estudiante.Nombre = Utilidades.NormalizarTexto(estudiante.Nombre);
                        estudiante.Apellido = Utilidades.NormalizarTexto(estudiante.Apellido);
                        estudiante.Correo = Utilidades.GenerarCorreo(estudiante);
                        _context.Update(estudiante);
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        ModelState.AddModelError("", "Verifica los campos Nombre, Apellido y Cédula.");
                        ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
                        return View(estudiante);
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EstudianteExists(estudiante.IdEstudiante))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCarrera"] = new SelectList(_context.Carreras, "IdCarrera", "Nombre", estudiante.IdCarrera);
            return View(estudiante);
        }

        // GET: Estudiantes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var estudiante = await _context.Estudiantes
                .Include(e => e.oCarrera)
                .FirstOrDefaultAsync(m => m.IdEstudiante == id);
            if (estudiante == null)
            {
                return NotFound();
            }

            return View(estudiante);
        }

        // POST: Estudiantes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var estudiante = await _context.Estudiantes.FindAsync(id);
            if (estudiante != null)
            {
                _context.Estudiantes.Remove(estudiante);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EstudianteExists(int id)
        {
            return _context.Estudiantes.Any(e => e.IdEstudiante == id);
        }
    }
}
