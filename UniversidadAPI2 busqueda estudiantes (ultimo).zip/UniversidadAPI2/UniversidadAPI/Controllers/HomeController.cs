using System.Diagnostics;
using UniversidadAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversidadAPI.Data;
using Microsoft.AspNetCore.Identity;

namespace UniversidadAPI.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // M�todo para validar si es admin
        private async Task<bool> ValidarAdministrador(string username, string password)
        {
            // Buscar el administrador en la base de datos
            var admin = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.UsuarioNombre == username && u.Rol == "Admin");

            // Comparar la contrase�a en texto claro
            if (admin != null && admin.Contrasena == password)
            {
                return true;
            }

            return false;
        }

        [HttpPost]
        public async Task<IActionResult> CrearUsuario(string NuevoUsuario, string NuevaContrase�a, string NuevoRol, string AdminUsuario, string AdminContrase�a)
        {
            // Validar que el AdminUsuario y AdminContrase�a sean correctos
            var admin = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.UsuarioNombre == AdminUsuario && u.Contrasena == AdminContrase�a && u.Rol == "Administrador");

            // Si no se encuentra el admin con ese nombre y contrase�a
            if (admin == null)
            {
                TempData["Error"] = "Usuario administrador no v�lido.";
                return RedirectToAction("Index"); // O la vista donde est�s
            }

            // Validar que el NuevoUsuario no exista ya
            var existeUsuario = await _context.Usuarios
                .AnyAsync(u => u.UsuarioNombre == NuevoUsuario);

            if (existeUsuario)
            {
                TempData["Error"] = "El nombre de usuario ya existe. Por favor elige otro.";
                return RedirectToAction("Index");
            }

            // Crear el nuevo usuario
            var usuario = new Usuario
            {
                UsuarioNombre = NuevoUsuario,
                Contrasena = NuevaContrase�a,
                Rol = NuevoRol
            };

            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Usuario creado exitosamente.";
            return RedirectToAction("Index");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
