﻿using System.ComponentModel.DataAnnotations.Schema;

namespace UniversidadAPI.Models
{

    [Table("Usuarios")] // Especifica el nombre correcto de la tabla
    public class Usuario
    {
        public int Id { get; set; }
        public string UsuarioNombre { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
        public string Rol { get; set; } = string.Empty; // Ej: "Admin", "Docente", "Estudiante"
    }
}
